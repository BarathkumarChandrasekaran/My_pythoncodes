# Student_Management_system-FLASK
STUDENT MANAGEMENT WEBSITE USING FLASK

Technology used:
1-> 	 Python (3.6)
2-> 	 Flask
3-> 	 SQLite3
4->	 HTML 5 , CSS 3, Bootstrap


Delete the database file
Run home.py 
use: "admin" as username and password
Set moderator & use the webiste
